<!-- Top Bar Start -->
<!--  <div class="top-bar">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="tb-contact">
                    <p><i class="fas fa-envelope"></i>info@mail.com</p>
                    <p><i class="fas fa-phone-alt"></i>+012 345 6789</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="tb-menu">
                    <a href="">About</a>
                    <a href="">Privacy</a>
                    <a href="">Terms</a>
                    <a href="">Contact</a>
                </div>
            </div>
        </div>
    </div>
</div> -->
<!-- Top Bar Start -->
<!-- Brand Start -->
<div class="brand">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-3 col-md-4">
                <div class="b-logo">
                    <a href="index.html">
                        <img src="img/logo.png" alt="Logo">
                    </a>
                </div>
            </div>
            <div class="col-lg-6 col-md-4">
                <div class="b-ads">
                    <a href="https://htmlcodex.com">
                        <!--<img src="img/ads-1.jpg" alt="Ads">-->
                    </a>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-4">
                    <div class="social ml-auto">
                    <a href="https://www.facebook.com/thenationaldawn/"><i class="fab fa-facebook-f"></i></a>
                                    <a href="https://twitter.com/thenationaldawn"><i class="fab fa-twitter"></i></a>
                                    <a href="https://www.instagram.com/thenationaldawn/"><i class="fab fa-instagram"></i></a>
                                    <a href="https://in.linkedin.com/in/the-national-dawn-b845421a1"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                <!--<div class="b-search">
                    <input type="text" placeholder="Search">
                    <button><i class="fa fa-search"></i></button>
                </div>-->
            </div>
        </div>
    </div>
</div>
<!-- Brand End -->